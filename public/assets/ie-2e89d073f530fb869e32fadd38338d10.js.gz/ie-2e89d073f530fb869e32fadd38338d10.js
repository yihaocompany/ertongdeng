$(function() {
	
	$('#content .post-item:nth-child(2n-1)').addClass('nomargin');	
	$('.second .post:nth-child(2n)').addClass('nomargin');	
	$('.custom-table tbody tr:nth-child(even) td').css({backgroundColor : '#fbfbfb'});
	
})()



;
